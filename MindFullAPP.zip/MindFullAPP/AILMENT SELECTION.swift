//
//  AILMENT SELECTION.swift
//  MINDFULLAPP
//
//  Created by Angelica Ellis on 11/18/22.
//

import SwiftUI

struct AILMENT_SELECTION: View {
    var body: some View {
        ZStack{
          Color(red: 37/255, green: 161/255, blue: 142/255).ignoresSafeArea()
          VStack {
              Spacer()
              Spacer()
              Text("Select your ailment:")
              .font(.title)
              .foregroundColor(Color.white)
              .multilineTextAlignment(.center)
        
              NavigationLink(destination: RESOURCES_PAGE()
                  .navigationBarBackButtonHidden(true)) {
                      Text("Depression").foregroundColor(.black)
                          .contentShape(Rectangle())
                          .frame(width: 268.0, height: 52.0)
                          .background(Color(red: 159/255, green: 255/255, blue: 203/255))
                          .clipShape(Capsule())
                  }
              
            Button("Bi-Polar Disorder") {
            }
            .padding()
            .frame(width: 268.0, height: 52.0)
            .background(Color(red: 159/255, green: 255/255, blue: 203/255))
            .clipShape(Capsule())
            .foregroundColor(.black)
       
            Button("Body Dysmorphia") {
              }
              .padding()
              .frame(width: 268.0, height: 52.0)
              .background(Color(red: 159/255, green: 255/255, blue: 203/255))
              .clipShape(Capsule())
              .foregroundColor(.black)
           
              Button("Anxiety") {
              }
              .padding()
              .frame(width: 268.0, height: 52.0)
              .background(Color(red: 159/255, green: 255/255, blue: 203/255))
              .clipShape(Capsule())
              .foregroundColor(.black)
              Spacer()
              Spacer()
          }
        }
      }
    }
struct AILMENT_SELECTION_Previews: PreviewProvider {
    static var previews: some View {
        AILMENT_SELECTION()
    }
}
