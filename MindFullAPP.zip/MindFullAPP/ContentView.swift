//
//  ContentView.swift
//  MindFullAPP
//
//  Created by David Bennett on 11/21/22.
//

import SwiftUI


struct ContentView: View {
    var body: some View {
        NavigationView {
            ContactDoc()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
