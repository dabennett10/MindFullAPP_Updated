//
//  PrivateChat.swift
//  MindFullAPP
//
//  Created by David Bennett on 11/21/22.
//

import SwiftUI

struct PrivateChat: View {
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    
    var body: some View {
        ZStack{
            Color(red: 37/255, green: 161/255, blue: 142/255).ignoresSafeArea()
            VStack{
                Button("Private Chat w/ @user") {
                }
                .padding()
                .font(.title2)
                .frame(width: 268.0, height: 52.0)
                .background(Color(red: 159/255, green: 255/255, blue: 203/255))
                .clipShape(Capsule())
                .foregroundColor(.black)
                //Spacing for gap between Heading/Chat Title and Chat Box
                Spacer().frame(width: 100, height: 20)
                
                ZStack{
                    Button(""){
                    }
                    .frame(width: 268.0, height: 465.0)
                    .background(Color(red: 159/255, green: 255/255, blue: 203/255))
                    .cornerRadius(/*@START_MENU_TOKEN@*/20.0/*@END_MENU_TOKEN@*/)
                    VStack{
                        HStack{
                            Image("Organizer")
                                .resizable()
                                .frame(width: 45.0, height: 45.0)
                            Rectangle().fill(Color(red: 37/255, green: 161/255, blue: 142/255)).overlay(Text("Text1")
                                .foregroundColor(.white))
                            .padding([.top, .bottom], 5)
                            .frame(width: 200.0, height: 52.0)
                            .cornerRadius(20)
                        }
                        HStack{
                            Rectangle().fill(Color(red: 255/255, green: 255/255, blue: 255/255)).overlay(Text("Text2")
                                .foregroundColor(.black))
                            .padding([.top, .bottom], 5)
                            .frame(width: 200.0, height: 52.0)
                            .cornerRadius(20)
                            Image("User").resizable()
                                .frame(width: 45.0, height: 45.0)
                        }
                        HStack{
                            Image("Organizer")
                                .resizable()
                                .frame(width: 45.0, height: 45.0)
                            Rectangle().fill(Color(red: 37/255, green: 161/255, blue: 142/255)).overlay(Text("Text3")
                                .foregroundColor(.white))
                            .padding([.top, .bottom], 5)
                            .frame(width: 200.0, height: 52.0)
                            .cornerRadius(20)
                        }
                        HStack{
                            Image("Organizer")
                                .resizable()
                                .frame(width: 45.0, height: 45.0)
                            Rectangle().fill(Color(red: 37/255, green: 161/255, blue: 142/255)).overlay(Text("Text4")
                                .foregroundColor(.white))
                            .padding([.top, .bottom], 5)
                            .frame(width: 200.0, height: 104.0)
                            .cornerRadius(20)
                        }
                        HStack{
                            Rectangle().fill(Color(red: 255/255, green: 255/255, blue: 255/255)).overlay(Text("Text5")
                                .foregroundColor(.black))
                            .padding([.top, .bottom], 5)
                            .frame(width: 200.0, height: 104.0)
                            .cornerRadius(20)
                            Image("User").resizable()
                                .frame(width: 45.0, height: 45.0)
                        }
                        HStack{
                            Image("Organizer")
                                .resizable()
                                .frame(width: 45.0, height: 45.0)
                            Rectangle().fill(Color(red: 37/255, green: 161/255, blue: 142/255)).overlay(Text("Text6")
                                .foregroundColor(.white))
                            .padding([.top, .bottom], 5)
                            .frame(width: 200.0, height: 52.0)
                            .cornerRadius(20)
                        }
                    }
                }
                
                Image(systemName: "keyboard")
                    .padding(.leading, 225.0)
                    .frame(width: 268.0, height: 52.0).clipShape(Capsule())
                    .background(Color(red: 159/255, green: 255/255, blue: 203/255))
                    .cornerRadius(/*@START_MENU_TOKEN@*/20.0/*@END_MENU_TOKEN@*/)
                
                NavigationLink(destination: RESOURCES_PAGE()
                          .navigationBarBackButtonHidden(true)) {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                              .resizable(resizingMode: .stretch)
                              .padding().frame(width: 75.0, height: 75.0)
                              .background(Color(red: 159/255, green: 255/255, blue: 203/255))
                              .clipShape(Circle())
                              .foregroundColor(.black)
                          }
                
              
                
                Text("Exit")
                    .font(.headline)
                    .foregroundColor(.black)
            }
        }.navigationBarBackButtonHidden(true)
            .navigationBarItems(leading: Button(action : {
                self.mode.wrappedValue.dismiss()
            }){
                Image(systemName: "arrow.left.circle.fill").resizable().foregroundColor(Color(red: 159/255, green: 255/255, blue: 203/255)).frame(width: 40, height: 40)
            })
    }
}

struct PrivateChat_Previews: PreviewProvider {
    static var previews: some View {
        PrivateChat()
    }
}
