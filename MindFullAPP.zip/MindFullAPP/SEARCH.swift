//
//  SEARCH.swift
//  MINDFULLAPP
//
//  Created by Angelica Ellis on 11/18/22.
//

import SwiftUI

struct SEARCH: View {
    @State var SearchTerm: String = ""
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    
    var body: some View {
        ZStack{
            Color(red: 37/255, green: 161/255, blue: 142/255).ignoresSafeArea()
            VStack {
                Text("Search Local Therapists")
                    .font(.largeTitle)
                    .foregroundColor(Color.white)
                    .multilineTextAlignment(.center)
                
                
                Text("This option will allow you to find a local therapist near you. Results are populated by using your location, address, city or zipcode.")
                    .font(.body)
                    .fontWeight(.medium)
                    .foregroundColor(Color.white)
                    .multilineTextAlignment(.center)
                
                
                HStack{
                    NavigationLink(destination: Therapists_List()
                        .navigationBarBackButtonHidden(true)) {
                            ZStack{
                                
                                Image(systemName: "magnifyingglass")
                                    .padding(.leading, 270.0)
                                    .frame(width: 340.0, height: 52.0).clipShape(Capsule())
                                    .background(Color.white
                                        .cornerRadius(20.0))
                                
                                
                                
                                
                                TextField("Search...", text: $SearchTerm)
                                    .padding(40.0)
                            }
                            
                        }
                }
            }
        }
        .navigationBarBackButtonHidden(true)
                    .navigationBarItems(leading: Button(action : {
                        self.mode.wrappedValue.dismiss()
                    }){
                        Image(systemName: "arrow.left.circle.fill").resizable().foregroundColor(.white).frame(width: 40, height: 40)
                    })
    }
}
struct SEARCH_Previews: PreviewProvider {
    static var previews: some View {
        SEARCH()
    }
}
