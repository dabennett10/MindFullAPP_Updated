//
//  MindFullAPPApp.swift
//  MindFullAPP
//
//  Created by David Bennett on 11/21/22.
//

import SwiftUI

@main
struct MindFullAPPApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
