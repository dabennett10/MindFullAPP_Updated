//
//  SplashScreen.swift
//  MindFullAPP
//
//  Created by David Bennett on 11/21/22.
//

import SwiftUI

struct SplashScreen: View {
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    var body: some View {
        ZStack{
            Color(red: 37/255, green: 161/255, blue: 142/255).ignoresSafeArea()
            VStack {
                Image("Logo")
                    .resizable()
                    .frame(width: 200.0, height: 200.0)
                Text("Welcome")
                    .font(.title)
                    .multilineTextAlignment(.center)
                
                        
                        
                        /*Text("@User").foregroundColor(.white)
                            .padding(.all)
                            .contentShape(Rectangle())
                            .frame(width: 268.0, height: 52.0)
                            .background(Color(red: 0/255, green: 78/255, blue: 100/255))
                            .clipShape(Capsule())*/
                NavigationLink(destination: AILMENT_SELECTION()
                    .navigationBarBackButtonHidden(true)) {
                        Text("@User").foregroundColor(.white)
                            .contentShape(Rectangle())
                            .frame(width: 268.0, height: 52.0)
                            .background(Color(red: 0/255, green: 78/255, blue: 100/255))
                            .clipShape(Capsule())
                    }
                
                Spacer(minLength: 230)
                GifView("grass_flow")
                            
                }
        }
    }
}

struct SplashScreen_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreen()
    }
}
